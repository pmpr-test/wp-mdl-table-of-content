<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fc58f36674             |
    |_______________________________________|
*/
 use Pmpr\Module\TableOfContent\TableOfContent; TableOfContent::symcgieuakksimmu();
