<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4f7cfce1             |
    |_______________________________________|
*/
 use Pmpr\Module\TableOfContent\TableOfContent; TableOfContent::symcgieuakksimmu();
