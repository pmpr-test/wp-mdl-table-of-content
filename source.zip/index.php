<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d3f622eb1             |
    |_______________________________________|
*/
 use Pmpr\Module\TableOfContent\TableOfContent; TableOfContent::symcgieuakksimmu();
