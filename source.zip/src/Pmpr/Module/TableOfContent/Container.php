<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4f7cfce1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { $yuumukkaswwoywya .= "\150{$iuimqckcgwwkgygo}\x3a\x6e\157\x74\x28\x5b\144\x61\x74\141\55\164\x72\x61\156\163\x6c\x61\x74\145\135\x29\x2c\x20\150{$iuimqckcgwwkgygo}\x5b\x64\x61\164\141\55\164\x72\141\156\163\x6c\x61\x74\145\x3d\x27\156\157\47\x5d\x2c"; } else { $yuumukkaswwoywya .= "\150{$iuimqckcgwwkgygo}\72\x6e\157\x74\50\133\151\x64\x5d\x29\54"; } } $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\54"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
