<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46f63b4c3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\x3a\x6e\x6f\x74\x28\133\144\141\x74\141\55\164\x72\x61\156\163\x6c\x61\x74\145\x5d\x29\54\40\x68{$iuimqckcgwwkgygo}\133\x64\x61\x74\141\x2d\164\x72\x61\x6e\163\x6c\141\x74\x65\75\47\x6e\x6f\47\135\54"; } else { $yuumukkaswwoywya .= "\150{$iuimqckcgwwkgygo}\x3a\156\x6f\164\x28\133\151\x64\x5d\51\x2c"; } } $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\54"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
