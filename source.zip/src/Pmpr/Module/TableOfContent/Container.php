<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ad721f57             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { $yuumukkaswwoywya .= "\150{$iuimqckcgwwkgygo}\x3a\156\157\x74\x28\133\x64\x61\164\141\x2d\x74\x72\141\156\x73\154\141\164\145\135\51\x2c\40\150{$iuimqckcgwwkgygo}\133\x64\141\164\141\x2d\x74\162\x61\156\163\x6c\141\164\145\75\47\156\x6f\x27\x5d\x2c"; } else { $yuumukkaswwoywya .= "\150{$iuimqckcgwwkgygo}\72\156\157\164\x28\133\151\x64\x5d\51\54"; } } $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\x2c"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
