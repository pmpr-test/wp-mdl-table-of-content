<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d004e4e4db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { $yuumukkaswwoywya .= "\150{$iuimqckcgwwkgygo}\72\156\x6f\x74\x28\x5b\x64\141\164\x61\x2d\x74\x72\141\x6e\x73\x6c\x61\x74\x65\135\x29\54\x20\x68{$iuimqckcgwwkgygo}\133\144\141\x74\x61\x2d\164\162\x61\156\x73\x6c\141\x74\x65\75\47\x6e\157\47\x5d\54"; } else { $yuumukkaswwoywya .= "\150{$iuimqckcgwwkgygo}\x3a\156\157\164\50\x5b\151\x64\135\51\x2c"; } } $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\x2c"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
