<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecbacd0be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { goto gaomwagkcciesyqy; } $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\x3a\x6e\157\x74\x28\x5b\x69\144\135\51\x2c"; goto aegysmeecgcgayyw; gaomwagkcciesyqy: $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\72\156\x6f\164\x28\133\x64\x61\x74\141\55\x74\x72\x61\x6e\x73\154\141\164\145\135\51\x2c\x20\150{$iuimqckcgwwkgygo}\133\x64\x61\164\x61\x2d\164\162\141\x6e\x73\x6c\141\164\145\75\47\x6e\157\47\x5d\54"; aegysmeecgcgayyw: esuiysskoweawsue: } uqqaiagaeqgqgaiy: $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\54"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
