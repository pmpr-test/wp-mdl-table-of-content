<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7cb3da02             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { goto gaomwagkcciesyqy; } $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\x3a\x6e\x6f\164\x28\133\151\144\135\x29\x2c"; goto aegysmeecgcgayyw; gaomwagkcciesyqy: $yuumukkaswwoywya .= "\150{$iuimqckcgwwkgygo}\72\x6e\157\x74\50\133\144\141\x74\141\x2d\164\162\x61\156\163\154\x61\x74\145\135\51\x2c\x20\x68{$iuimqckcgwwkgygo}\133\144\x61\164\141\55\164\x72\x61\x6e\x73\x6c\141\x74\145\75\47\x6e\x6f\x27\x5d\54"; aegysmeecgcgayyw: esuiysskoweawsue: } uqqaiagaeqgqgaiy: $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\54"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
