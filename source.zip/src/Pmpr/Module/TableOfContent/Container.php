<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517959d63e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { goto usquiuuyiyqaeyiu; } $yuumukkaswwoywya .= "\150{$iuimqckcgwwkgygo}\x3a\x6e\x6f\164\x28\x5b\x69\x64\x5d\x29\54"; goto qicwaskssogcokgm; usquiuuyiyqaeyiu: $yuumukkaswwoywya .= "\150{$iuimqckcgwwkgygo}\72\156\x6f\164\x28\133\144\x61\x74\x61\55\164\x72\x61\x6e\163\154\141\x74\x65\135\x29\54\40\x68{$iuimqckcgwwkgygo}\133\144\141\x74\x61\55\x74\x72\x61\156\x73\154\141\x74\x65\75\47\156\x6f\47\135\54"; qicwaskssogcokgm: kymkucucyeoeikim: } hoeeyiowekaeemko: $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\54"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
