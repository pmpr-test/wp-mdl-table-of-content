<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d835c299c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function esciskwmewkgwaik() : array { return Setting::symcgieuakksimmu()->esciskwmewkgwaik(); } public function gmiiaymeiwkykcym(string $ewgwqamkygiqaawc, bool $boeioycsyqgqmoeu = true) : bool { $yuumukkaswwoywya = ''; foreach ($this->weysguygiseoukqw(Setting::skqaqgkgaueeyosa, []) as $iuimqckcgwwkgygo) { if ($boeioycsyqgqmoeu) { $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\x3a\156\x6f\164\x28\x5b\x64\x61\x74\x61\55\x74\x72\141\156\163\154\x61\164\x65\x5d\x29\54\x20\150{$iuimqckcgwwkgygo}\x5b\144\141\x74\x61\x2d\164\x72\x61\x6e\163\154\x61\x74\145\x3d\47\x6e\x6f\x27\x5d\x2c"; } else { $yuumukkaswwoywya .= "\x68{$iuimqckcgwwkgygo}\72\x6e\x6f\x74\x28\x5b\x69\x64\x5d\x29\x2c"; } } $yuumukkaswwoywya = rtrim($yuumukkaswwoywya, "\x2c"); return !$this->caokeucsksukesyo()->gkksucgseqqemesc()->has(stripslashes($ewgwqamkygiqaawc), $yuumukkaswwoywya); } }
