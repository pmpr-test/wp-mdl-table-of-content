<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705dbe60df1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\TableOfContent\Traits\RenderTrait; class Frontend extends Container { use RenderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\150\x65\137\x63\157\x6e\164\x65\x6e\164", [$this, "\141\x69\155\x79\x63\x6d\153\x77\x6f\x73\x73\147\x61\x73\x67\x73"], 999); } public function wigskegsqequoeks() { $this->waqewsckuayqguos(TableOfContent::qmkskkcukqigsimq . "\162\x65\x6e\144\145\162", [$this, "\x72\x65\156\x64\x65\162"]); } public function aimycmkwossgasgs($ewgwqamkygiqaawc) { if ($this->uiqcwsowwswommka()) { $ewgwqamkygiqaawc = $this->wgqqgewcmcemoewo() . $ewgwqamkygiqaawc; } return $ewgwqamkygiqaawc; } public function wgqqgewcmcemoewo() : string { return $this->iuygowkemiiwqmiw("\146\162\157\156\x74\145\156\144", $this->eeisgyksyecuceue([Constants::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::aekmoagaweyqgyeo), Constants::ayscagukkeoucmoe => $this->weysguygiseoukqw(Constants::ayscagukkeoucmoe)])); } public function render() { if ($this->uiqcwsowwswommka()) { echo $this->wgqqgewcmcemoewo(); } } }
