<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4f7cfce1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\TableOfContent\Traits\RenderTrait; class Frontend extends Container { use RenderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\150\145\137\143\x6f\156\x74\x65\156\x74", [$this, "\141\x69\x6d\171\143\x6d\153\x77\157\163\163\x67\141\x73\147\163"], 999); } public function wigskegsqequoeks() { $this->waqewsckuayqguos(TableOfContent::qmkskkcukqigsimq . "\x72\145\x6e\x64\145\162", [$this, "\x72\x65\156\x64\145\x72"]); } public function aimycmkwossgasgs($ewgwqamkygiqaawc) { if ($this->uiqcwsowwswommka()) { $ewgwqamkygiqaawc = $this->wgqqgewcmcemoewo() . $ewgwqamkygiqaawc; } return $ewgwqamkygiqaawc; } public function wgqqgewcmcemoewo() : string { return $this->iuygowkemiiwqmiw("\146\x72\x6f\156\164\145\156\144", $this->eeisgyksyecuceue([Constants::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::aekmoagaweyqgyeo), Constants::ayscagukkeoucmoe => $this->weysguygiseoukqw(Constants::ayscagukkeoucmoe)])); } public function render() { if ($this->uiqcwsowwswommka()) { echo $this->wgqqgewcmcemoewo(); } } }
