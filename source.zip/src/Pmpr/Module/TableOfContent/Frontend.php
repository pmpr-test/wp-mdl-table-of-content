<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d004e4e4db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\TableOfContent\Traits\RenderTrait; class Frontend extends Container { use RenderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\150\x65\137\143\157\156\164\x65\156\164", [$this, "\141\151\x6d\171\143\x6d\153\x77\157\x73\163\147\x61\163\147\163"], 999); } public function wigskegsqequoeks() { $this->waqewsckuayqguos(TableOfContent::qmkskkcukqigsimq . "\x72\x65\156\144\145\162", [$this, "\x72\x65\156\144\145\x72"]); } public function aimycmkwossgasgs($ewgwqamkygiqaawc) { if ($this->uiqcwsowwswommka()) { $ewgwqamkygiqaawc = $this->wgqqgewcmcemoewo() . $ewgwqamkygiqaawc; } return $ewgwqamkygiqaawc; } public function wgqqgewcmcemoewo() : string { return $this->iuygowkemiiwqmiw("\x66\162\157\156\164\145\156\144", $this->eeisgyksyecuceue([Constants::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::aekmoagaweyqgyeo), Constants::ayscagukkeoucmoe => $this->weysguygiseoukqw(Constants::ayscagukkeoucmoe)])); } public function render() { if ($this->uiqcwsowwswommka()) { echo $this->wgqqgewcmcemoewo(); } } }
