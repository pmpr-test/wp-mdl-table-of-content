<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d835c299c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TableOfContent; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\TableOfContent\Traits\RenderTrait; class Frontend extends Container { use RenderTrait; public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\164\150\x65\137\x63\x6f\156\164\x65\x6e\164", [$this, "\141\x69\x6d\171\x63\x6d\x6b\167\x6f\x73\163\147\x61\163\147\x73"], 999); } public function wigskegsqequoeks() { $this->waqewsckuayqguos(TableOfContent::qmkskkcukqigsimq . "\x72\x65\x6e\x64\145\x72", [$this, "\x72\145\x6e\x64\x65\x72"]); } public function aimycmkwossgasgs($ewgwqamkygiqaawc) { if ($this->uiqcwsowwswommka()) { $ewgwqamkygiqaawc = $this->wgqqgewcmcemoewo() . $ewgwqamkygiqaawc; } return $ewgwqamkygiqaawc; } public function wgqqgewcmcemoewo() : string { return $this->iuygowkemiiwqmiw("\146\162\157\156\164\145\x6e\x64", $this->eeisgyksyecuceue([Constants::qescuiwgsyuikume => $this->weysguygiseoukqw(Setting::aekmoagaweyqgyeo), Constants::ayscagukkeoucmoe => $this->weysguygiseoukqw(Constants::ayscagukkeoucmoe)])); } public function render() { if ($this->uiqcwsowwswommka()) { echo $this->wgqqgewcmcemoewo(); } } }
